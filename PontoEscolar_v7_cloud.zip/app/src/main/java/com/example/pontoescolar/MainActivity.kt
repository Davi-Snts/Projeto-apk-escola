package com.example.pontoescolar

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("ponto_escolar", Context.MODE_PRIVATE) }
    private val dateFmt = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
    private val timeFmt = SimpleDateFormat("HH:mm", Locale("pt", "BR"))
    private lateinit var content: LinearLayout
    private lateinit var todayStatus: TextView
    private fun dp(n:Int)= (n*resources.displayMetrics.density).toInt()
    private fun text(s:String, size:Float=16f)=TextView(this).apply{text=s;textSize=size;setTextColor(Color.rgb(15,23,42));setPadding(dp(14),dp(8),dp(14),dp(8))}
    private fun button(s:String, action:()->Unit)=Button(this).apply{text=s;setOnClickListener{action()}}
    override fun onCreate(b:Bundle?){super.onCreate(b);build()}
    private fun build(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(10),dp(14),dp(8));setBackgroundColor(Color.rgb(248,250,252))}
        root.addView(text("🏫  PONTO ESCOLAR",25f).apply{setTypeface(null,Typeface.BOLD);setPadding(dp(8),dp(8),dp(8),0)})
        root.addView(text("Seu controle de presença e tarefas",14f).apply{setTextColor(Color.rgb(71,85,105));setPadding(dp(8),0,dp(8),dp(10))})
        todayStatus=text("",18f).apply{setPadding(dp(18),dp(18),dp(18),dp(18));setBackgroundColor(Color.WHITE);setTypeface(null,Typeface.BOLD)};root.addView(todayStatus,LinearLayout.LayoutParams(-1,dp(125)).apply{setMargins(0,dp(4),0,dp(10))})
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        row.addView(button("🟢 ENTRADA"){punch("in")},LinearLayout.LayoutParams(0,dp(54),1f).apply{setMargins(0,0,dp(5),0)})
        row.addView(button("🔴 SAÍDA"){punch("out")},LinearLayout.LayoutParams(0,dp(54),1f).apply{setMargins(dp(5),0,0,0)});root.addView(row)
        val nav=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        nav.addView(button("📅\nCalendário"){calendar()},LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(0,0,dp(4),0)})
        nav.addView(button("📊\nResumo"){stats()},LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(dp(2),0,dp(2),0)})
        nav.addView(button("📝\nTarefas"){tasks()},LinearLayout.LayoutParams(0,dp(58),1f).apply{setMargins(dp(4),0,0,0)})
        root.addView(nav)
        val scroll=ScrollView(this);content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};scroll.addView(content);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root);refresh();history()
    }
    private fun key(type:String,d:String)="${type}_$d"
    private fun punch(type:String){
        val d=dateFmt.format(Date())
        if(prefs.getBoolean(key("abs",d),false)){Toast.makeText(this,"Hoje está marcado como falta. Altere o registro do dia antes de bater o ponto.",Toast.LENGTH_LONG).show();return}
        if(type=="out" && !prefs.contains(key("in",d))){Toast.makeText(this,"Registre a entrada antes da saída.",Toast.LENGTH_SHORT).show();return}
        if(prefs.contains(key(type,d))){Toast.makeText(this,if(type=="in")"A entrada de hoje já foi registrada." else "A saída de hoje já foi registrada.",Toast.LENGTH_SHORT).show();return}
        prefs.edit().putString(key(type,d),timeFmt.format(Date())).apply();refresh();history();Toast.makeText(this,if(type=="in")"Entrada registrada!" else "Saída registrada!",Toast.LENGTH_SHORT).show()
    }
    private fun refresh(){val d=dateFmt.format(Date());val i=prefs.getString(key("in",d),null);val o=prefs.getString(key("out",d),null);val absent=prefs.getBoolean(key("abs",d),false);val state=when{absent->"✕ FALTA REGISTRADA";i!=null&&o!=null->"✓ PRESENÇA REGISTRADA";i!=null->"⏱ EM AULA";else->"○ SEM PONTO"};todayStatus.text="HOJE • $d\n\n$state\n\nEntrada: ${i?:"—"}     Saída: ${o?:"—"}"}
    private fun clear(){content.removeAllViews()}
    private fun history(){clear();content.addView(text("📋 Histórico de presença",21f).apply{setTypeface(null,Typeface.BOLD);setPadding(dp(6),dp(8),dp(6),dp(10))});val dates=prefs.all.keys.filter{it.startsWith("in_")||it.startsWith("out_")||it.startsWith("abs_")}.map{it.substringAfter("_")}.toSet().sortedByDescending{parse(it)};if(dates.isEmpty()){content.addView(text("Nenhum registro. Bata sua entrada para começar."));return};dates.forEach{d->val i=prefs.getString(key("in",d),"—");val o=prefs.getString(key("out",d),"—");val status=if(prefs.getBoolean(key("abs",d),false))"Falta" else if(i!="—")"Presente" else "Sem ponto";val card=text("📌 $d\n   $status   •   Entrada: $i   •   Saída: $o",16f);card.setBackgroundColor(Color.WHITE);card.setPadding(dp(16),dp(14),dp(16),dp(14));content.addView(card)}}
    private fun parse(s:String)=try{dateFmt.parse(s)?.time?:0}catch(_:Exception){0}
    private fun calendar(){
        clear();content.addView(text("📅 Calendário de presença",21f).apply{setTypeface(null,Typeface.BOLD);setPadding(dp(6),dp(8),dp(6),dp(10))})
        val now=Calendar.getInstance();showMonth(now.get(Calendar.YEAR),now.get(Calendar.MONTH))
    }
    private fun showMonth(y:Int,m:Int){
        val month=Calendar.getInstance().apply{set(y,m,1)};content.addView(text(SimpleDateFormat("MMMM 'de' yyyy",Locale("pt","BR")).format(month.time).replaceFirstChar{it.uppercase()},18f))
        val week=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};listOf("D","S","T","Q","Q","S","S").forEach{week.addView(text(it,13f).apply{gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,dp(34),1f))};content.addView(week)
        val start=month.get(Calendar.DAY_OF_WEEK)-1;var row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};repeat(start){row.addView(space(),LinearLayout.LayoutParams(0,dp(64),1f))}
        val max=month.getActualMaximum(Calendar.DAY_OF_MONTH)
        for(day in 1..max){val c=Calendar.getInstance().apply{set(y,m,day)};val d=dateFmt.format(c.time);val present=prefs.contains(key("in",d));val absent=prefs.getBoolean(key("abs",d),false);val marker=when{absent->"✕";present->"✓";else->""};val bg=when{absent->Color.rgb(254,226,226);present->Color.rgb(220,252,231);else->Color.WHITE};val cell=text("$day\n$marker",14f).apply{gravity=Gravity.CENTER;setBackgroundColor(bg);setOnClickListener{dayDetails(d)}};row.addView(cell,LinearLayout.LayoutParams(0,dp(64),1f).apply{setMargins(dp(2),dp(2),dp(2),dp(2))});if((start+day)%7==0){content.addView(row);row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}}};if(row.childCount>0)content.addView(row)
        content.addView(text("✓ Presença     ✕ Falta"))
        content.addView(button("📊 Ver estatísticas"){stats()})
    }
    private fun dayDetails(d:String){val i=prefs.getString(key("in",d),"—");val o=prefs.getString(key("out",d),"—");val absent=prefs.getBoolean(key("abs",d),false);val status=if(absent)"Falta" else if(i!="—")"Presente" else "Sem registro";val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),dp(8),dp(8),dp(8))};box.addView(text("Entrada: $i"));box.addView(text("Saída: $o"));box.addView(text("Status: $status"));val cb=CheckBox(this).apply{text="Marcar como falta";isChecked=absent};box.addView(cb);box.addView(button("📝 Nova tarefa para este dia"){taskDialog(d)});AlertDialog.Builder(this).setTitle("Dia $d").setView(box).setNegativeButton("Fechar",null).setPositiveButton("Salvar"){_,_->prefs.edit().putBoolean(key("abs",d),cb.isChecked).apply();refresh();calendar()}.show()}
    private fun stats(){clear();content.addView(text("📊 Resumo de presença",21f).apply{setTypeface(null,Typeface.BOLD);setPadding(dp(6),dp(8),dp(6),dp(10))});val dates=prefs.all.keys.filter{it.startsWith("in_")||it.startsWith("out_")||it.startsWith("abs_")}.map{it.substringAfter("_")}.toSet();val abs=dates.count{prefs.getBoolean(key("abs",it),false)};val present=dates.count{!prefs.getBoolean(key("abs",it),false)&&prefs.contains(key("in",it))};val registered=present+abs;val pct=if(registered==0)0 else present*100/registered;content.addView(text("Dias registrados: $registered\n\n✓ Presentes: $present\n✕ Faltas: $abs\n\nFrequência: $pct%",19f));content.addView(button("📅 Voltar ao calendário"){calendar()})}
    private fun space()=Space(this)
    private fun tasks(){
        clear(); content.addView(text("📝 Minhas tarefas",21f).apply{setTypeface(null,Typeface.BOLD);setPadding(dp(6),dp(8),dp(6),dp(10))})
        val selected=dateFmt.format(Date())
        content.addView(text("Hoje • $selected",15f))
        content.addView(button("＋ Nova tarefa para hoje"){taskDialog(selected)})
        val tasks=loadTasks().sortedWith(compareBy<Task>{it.date}.thenBy{it.id})
        if(tasks.isEmpty()){content.addView(text("Nenhuma tarefa adicionada."));return}
        tasks.groupBy{it.date}.toSortedMap(compareByDescending{parse(it)}).forEach{(d,list)->
            content.addView(text("📅 $d",18f).apply{setTypeface(null,Typeface.BOLD)})
            list.forEach{t->
                val cb=CheckBox(this).apply{text=t.text;isChecked=t.done;textSize=16f;setOnCheckedChangeListener{_,v->if(t.done!=v){t.done=v;saveTasks(tasks)}}}
                cb.setOnLongClickListener{taskDialog(t.date,t);true}
                content.addView(cb)
            }
        }
        content.addView(text("Dica: toque e segure uma tarefa para editar ou excluir.",13f))
    }
    data class Task(var id:Long,var date:String,var text:String,var done:Boolean)
    private fun loadTasks():MutableList<Task>{
        val raw=prefs.getString("tasks_v4","") ?: ""
        if(raw.isBlank()) return mutableListOf()
        return raw.split("\n").mapNotNull{line->
            val a=line.split("|",limit=4); if(a.size<4) null else try{Task(a[0].toLong(),a[1],a[2].replace("\\n","\n").replace("\\p","|"),a[3]=="1")}catch(_:Exception){null}
        }.toMutableList()
    }
    private fun saveTasks(tasks:List<Task>){
        val raw=tasks.joinToString("\n"){t->"${t.id}|${t.date}|${t.text.replace("|","\\p").replace("\n","\\n")}|${if(t.done)1 else 0}"}
        prefs.edit().putString("tasks_v4",raw).apply()
    }
    private fun taskDialog(date:String, existing:Task?=null){
        val input=EditText(this).apply{hint="Nome da tarefa";setText(existing?.text ?: "")}
        val b=AlertDialog.Builder(this).setTitle(if(existing==null)"Adicionar tarefa" else "Editar tarefa").setMessage("Dia: $date").setView(input).setNegativeButton("Cancelar",null)
        b.setPositiveButton(if(existing==null)"Adicionar" else "Salvar"){_,_->
            val value=input.text.toString().trim(); if(value.isNotEmpty()){val list=loadTasks();if(existing==null) list.add(Task(System.currentTimeMillis(),date,value,false)) else list.find{it.id==existing.id}?.text=value;saveTasks(list);tasks()}
        }
        if(existing!=null)b.setNeutralButton("Excluir"){_,_->val list=loadTasks().filterNot{it.id==existing.id};saveTasks(list);tasks()}
        b.show()
    }


}
